package com.automate.vehicle;

import android.app.*;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content, nav;
    int teal = Color.rgb(20,184,166), navy = Color.rgb(15,23,42), card = Color.rgb(30,41,59);
    int text = Color.rgb(241,245,249), muted = Color.rgb(148,163,184), bg = Color.rgb(11,18,32);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(bg);
        showHome();
    }

    TextView tv(String s, float size, int color) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(size); v.setTextColor(color);
        v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        v.setPadding(18, 8, 18, 8);
        v.setTypeface(Typeface.DEFAULT, size >= 18 ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }

    GradientDrawable shape(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(r); return g;
    }

    TextView button(String s) {
        TextView b = tv(s, 14, text);
        b.setGravity(Gravity.CENTER);
        b.setBackground(shape(Color.rgb(38,52,74), 28));
        b.setPadding(20, 8, 20, 8);
        return b;
    }

    LinearLayout box() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(18,16,18,16);
        l.setBackground(shape(card, 28));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0,0,0,14); l.setLayoutParams(p);
        return l;
    }

    void base(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,18,18,8); root.setBackgroundColor(bg);
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        nav = new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setPadding(4,6,4,4);
        String[] labels={"خانه","خودروها","سرویس","سوابق","هشدارها"};
        for(String x:labels){ TextView b=button(x); b.setTextSize(12); nav.addView(b,new LinearLayout.LayoutParams(0,58,1)); }
        ((TextView)nav.getChildAt(0)).setOnClickListener(v->showHome());
        ((TextView)nav.getChildAt(1)).setOnClickListener(v->showVehicles());
        ((TextView)nav.getChildAt(2)).setOnClickListener(v->showService());
        ((TextView)nav.getChildAt(3)).setOnClickListener(v->showHistory());
        ((TextView)nav.getChildAt(4)).setOnClickListener(v->showAlerts());
        root.addView(nav);
        setContentView(root);
    }

    void header(String title, String sub) {
        LinearLayout h=new LinearLayout(this); h.setOrientation(LinearLayout.VERTICAL); h.setPadding(4,2,4,18);
        h.addView(tv(sub,13,muted)); h.addView(tv(title,27,text));
        content.addView(h);
    }

    void showHome(){
        base("خانه"); header("AutoMate","دفترچه هوشمند خودرو و موتور");
        LinearLayout hero=box();
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout names=new LinearLayout(this); names.setOrientation(LinearLayout.VERTICAL);
        names.addView(tv("BMW 320i",22,text)); names.addView(tv("2018  •  2.0 Turbo",13,muted)); names.addView(tv("92,430 km",16,text));
        row.addView(names,new LinearLayout.LayoutParams(0,-2,1)); row.addView(tv("🚗",38,text));
        hero.addView(row); content.addView(hero);
        LinearLayout stats=new LinearLayout(this);
        TextView a=stat("سرویس بعدی","2,430 km"), b=stat("یادآوری فعال","3 مورد");
        stats.addView(a,new LinearLayout.LayoutParams(0,-2,1)); stats.addView(b,new LinearLayout.LayoutParams(0,-2,1));
        content.addView(stats);
        LinearLayout smart=box(); smart.addView(tv("🧠 پیشنهاد هوشمند",17,text));
        smart.addView(tv("بر اساس کارکرد و سوابق، بررسی روغن موتور و فیلتر هوا نزدیک شده است.",14,muted));
        TextView go=button("مشاهده جزئیات"); go.setOnClickListener(v->showAlerts()); smart.addView(go);
        content.addView(smart);
        TextView add=button("＋ ثبت سرویس جدید"); add.setOnClickListener(v->showService()); content.addView(add);
    }

    TextView stat(String a,String b){
        TextView v=tv(a+"\n"+b,14,text); v.setGravity(Gravity.RIGHT); v.setPadding(18,16,18,16); v.setBackground(shape(card,24));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1); p.setMargins(0,0,8,14); v.setLayoutParams(p); return v;
    }

    void showVehicles(){
        base("خودروها"); header("وسایل نقلیه من","هر ماشین یا موتورسیکلت، پرونده‌ی جداگانه");
        vehicle("🚗","BMW 320i","2018  •  92,430 km");
        vehicle("🏍️","موتورسیکلت من","برای افزودن مشخصات آماده است");
        TextView add=button("＋ افزودن خودرو یا موتور"); add.setOnClickListener(v->toast("فرم افزودن وسیله در نسخه کامل فعال می‌شود.")); content.addView(add);
    }
    void vehicle(String icon,String name,String sub){
        LinearLayout x=box(); LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(tv(icon,34,text)); LinearLayout n=new LinearLayout(this); n.setOrientation(LinearLayout.VERTICAL);
        n.addView(tv(name,17,text)); n.addView(tv(sub,13,muted)); r.addView(n,new LinearLayout.LayoutParams(0,-2,1));
        r.addView(tv("›",28,muted)); x.addView(r); content.addView(x);
    }

    void showService(){
        base("ثبت سرویس"); header("ثبت سرویس جدید","اطلاعات واقعی سرویس را ثبت کن تا برنامه موعد بعدی را محاسبه کند");
        LinearLayout f=box();
        f.addView(tv("نوع سرویس",13,muted));
        Spinner sp=new Spinner(this); String[] items={"روغن موتور","فیلتر روغن","فیلتر هوا","لنت ترمز","شمع","سایر"};
        sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,items)); f.addView(sp);
        EditText km=new EditText(this); km.setHint("کارکرد هنگام سرویس"); km.setInputType(2); km.setText("92430"); km.setTextColor(text); km.setHintTextColor(muted); f.addView(km);
        EditText cost=new EditText(this); cost.setHint("هزینه (اختیاری)"); cost.setInputType(2); cost.setTextColor(text); cost.setHintTextColor(muted); f.addView(cost);
        TextView save=button("ذخیره سرویس"); save.setOnClickListener(v->{ if(km.getText().toString().trim().isEmpty()) toast("کارکرد را وارد کن."); else toast("سرویس ثبت شد؛ موعد بعدی محاسبه می‌شود."); }); f.addView(save);
        content.addView(f);
    }

    void showHistory(){
        base("سوابق"); header("سوابق سرویس","تاریخچه کامل تعمیر و نگهداری");
        history("روغن موتور","90,000 km","۳ ماه پیش");
        history("فیلتر هوا","87,500 km","۷ ماه پیش");
        history("لنت جلو","81,200 km","۱۱ ماه پیش");
    }
    void history(String a,String b,String c){ LinearLayout x=box(); x.addView(tv(a,17,text)); x.addView(tv(b+"  •  "+c,13,muted)); content.addView(x); }

    void showAlerts(){
        base("هشدارها"); header("یادآوری‌ها","موارد نزدیک یا مهم را اینجا ببین");
        alert("🔔","روغن موتور","حدود 2,430 کیلومتر تا سرویس بعدی");
        alert("🔔","فیلتر هوا","حدود 5,000 کیلومتر تا بررسی بعدی");
        alert("🟡","بازدید لنت ترمز","بر اساس برنامه سرویس، بررسی پیشنهاد می‌شود.");
    }
    void alert(String icon,String a,String b){ LinearLayout x=box(); x.addView(tv(icon+"  "+a,17,text)); x.addView(tv(b,13,muted)); content.addView(x); }

    void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
}
