# ساخت APK بدون Android Studio

این پروژه یک workflow آماده GitHub Actions دارد و می‌تواند APK را در فضای ابری GitHub بسازد.

1. در GitHub یک Repository جدید بسازید.
2. تمام فایل‌های این پوشه را داخل Repository آپلود کنید و روی `main` قرار دهید.
3. به تب **Actions** بروید و workflow با نام **Build AutoMate APK** را اجرا کنید.
4. بعد از پایان Build، در صفحه اجرای workflow بخش **Artifacts** فایل `AutoMate-debug-apk` را دانلود کنید.
5. داخل فایل ZIP، `app-debug.apk` قرار دارد؛ آن را روی گوشی نصب کنید.

این روش به Android Studio روی کامپیوتر شما نیاز ندارد.
